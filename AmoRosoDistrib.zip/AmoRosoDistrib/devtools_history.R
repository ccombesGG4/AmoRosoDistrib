# Start documentation
usethis::use_vignette("how to use the package")

# Add the following packages
usethis::use_package("stats")
usethis::use_package("graphics")

# Ignore this file
usethis::use_build_ignore("devtools_history.R")
